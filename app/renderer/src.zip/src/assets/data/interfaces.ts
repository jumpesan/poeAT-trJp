import type { ItemCategory } from '@/parser'

export interface StatMatcher {
  string: string
  advanced?: string
  negate?: true
  value?: number
  oils?: string // Amulet anointment
}

export enum StatBetter {
  NegativeRoll = -1,
  PositiveRoll = 1,
  NotComparable = 0
}

export interface Stat {
  ref: string
  dp?: true
  matchers: StatMatcher[]
  better: StatBetter
  fromAreaMods?: 'yes' | 'ubermap_exclusive' | 'heist_exclusive'
  anointments?: Array<{ roll: number, oils: string }> // Ring anointments
  trade: {
    inverted?: true
    option?: true
    ids: {
      [type: string]: string[]
    }
  }
}

export interface StatGroup {
  resolve: StatGroupResolver
  stats: Stat[]
}

export type StatOrGroup = Stat | StatGroup

export type StatGroupResolver =
  {
    strat: 'select'
    test: Array<string | null>
  } | {
    strat: 'trivial-merge'
  } | {
    strat: 'percent-merge'
    kind: Array<'percent' | 'value'>
  } | {
    strat: 'flag-merge'
    kind: Array<'flag' | 'value'>
  }

export interface DropEntry {
  query: string[]
  items: string[]
}

export interface BaseType {
  name: string
  refName: string
  namespace: (
    'DIVINATION_CARD' |
    'CAPTURED_BEAST' |
    'UNIQUE' |
    'ITEM' |
    'GEM'
  )
  icon: string
  w?: number
  h?: number
  tradeTag?: string
  exchangeable?: true
  tradeDisc?: string
  disc?: {
    propAR?: true
    propEV?: true
    propES?: true
    hasImplicit?: { ref: Stat['ref'] }
    hasExplicit?: { ref: Stat['ref'] }
    sectionText?: string
    mapTier?: 'W' | 'Y' | 'R'
  }
  // extra info
  craftable?: {
    category: ItemCategory
    corrupted?: true
    uniqueOnly?: true
  }
  unique?: {
    base: BaseType['refName']
    fixedStats?: Array<Stat['ref']>
    disenchantValue?: number
  }
  map?: {
    screenshot?: string
  }
  gem?: {
    vaal?: true
    transfigured?: true
    normalVariant?: BaseType['refName']
    maxLevel: number
  }
  armour?: {
    ar?: [min: number, max: number]
    ev?: [min: number, max: number]
    es?: [min: number, max: number]
    ward?: [min: number, max: number]
  }
}

export interface TranslationDict {
  RARITY_NORMAL: string
  RARITY_MAGIC: string
  RARITY_RARE: string
  RARITY_UNIQUE: string
  RARITY_GEM: string
  RARITY_CURRENCY: string
  RARITY_DIVCARD: string
  RARITY_QUEST: string
  MAP_TIER: RegExp
  MAP_ITEM_QUANTITY: string
  MAP_ITEM_RARITY: string
  MAP_MONSTER_PACK_SIZE: string
  MAP_MORE_MAPS: string
  MAP_MORE_SCARABS: string
  MAP_MORE_CURRENCY: string
  MAP_MORE_DIVINATION_CARDS: string
  MAP_COMPLETION_REWARD: RegExp
  RARITY: string
  ITEM_CLASS: string
  ITEM_LEVEL: string
  CORPSE_LEVEL: string
  TALISMAN_TIER: string
  GEM_LEVEL: string
  STACK_SIZE: string
  SOCKETS: string
  QUALITY: string
  MEMORY_STRANDS: string
  PHYSICAL_DAMAGE: string
  ELEMENTAL_DAMAGE: string
  CRIT_CHANCE: string
  ATTACK_SPEED: string
  ARMOUR: string
  EVASION: string
  ENERGY_SHIELD: string
  TAG_WARD: string
  BLOCK_CHANCE: string
  CORRUPTED: string
  UNIDENTIFIED: string
  ITEM_SUPERIOR: RegExp
  MAP_BLIGHTED: RegExp
  MAP_BLIGHT_RAVAGED: RegExp
  INFLUENCE_SHAPER: string
  INFLUENCE_ELDER: string
  INFLUENCE_CRUSADER: string
  INFLUENCE_HUNTER: string
  INFLUENCE_REDEEMER: string
  INFLUENCE_WARLORD: string
  SECTION_SYNTHESISED: string
  ITEM_SYNTHESISED: RegExp
  VEILED_PREFIX: string
  VEILED_SUFFIX: string
  FLASK_CHARGES: RegExp
  METAMORPH_HELP: string
  BEAST_HELP: string
  VOIDSTONE_HELP: string
  METAMORPH_BRAIN: RegExp
  METAMORPH_EYE: RegExp
  METAMORPH_LUNG: RegExp
  METAMORPH_HEART: RegExp
  METAMORPH_LIVER: RegExp
  CANNOT_USE_ITEM: string
  QUALITY_ANOMALOUS: RegExp
  QUALITY_DIVERGENT: RegExp
  QUALITY_PHANTASMAL: RegExp
  AREA_LEVEL: string
  HEIST_WINGS_REVEALED: string
  HEIST_BLUEPRINT_TARGET: string
  HEIST_BLUEPRINT_ENCHANTS: string
  HEIST_BLUEPRINT_TRINKETS: string
  HEIST_BLUEPRINT_GEMS: string
  HEIST_BLUEPRINT_REPLICAS: string
  HEIST_CONTRACT_JOB: RegExp
  HEIST_JOB_LOCKPICKING: string
  HEIST_JOB_BRUTEFORCE: string
  HEIST_JOB_PERCEPTION: string
  HEIST_JOB_DEMOLITION: string
  HEIST_JOB_COUNTERTHAUMATURGY: string
  HEIST_JOB_TRAPDISARMAMENT: string
  HEIST_JOB_AGILITY: string
  HEIST_JOB_DECEPTION: string
  HEIST_JOB_ENGINEERING: string
  HEIST_CONTRACT_TARGET: RegExp
  HEIST_TARGET_PRICELESS: string
  MIRRORED: string
  SPLIT: string
  MODIFIER_LINE: RegExp
  PREFIX_MODIFIER: string
  SUFFIX_MODIFIER: string
  CRAFTED_PREFIX: string
  CRAFTED_SUFFIX: string
  IMPLICIT_MODIFIER: string
  FRACTURED_PREFIX: string
  FRACTURED_SUFFIX: string
  UNSCALABLE_VALUE: string
  CORRUPTED_IMPLICIT: string
  MODIFIER_INCREASED: RegExp
  INCURSION_OPEN: string
  INCURSION_OBSTRUCTED: string
  EATER_IMPLICIT: RegExp
  EXARCH_IMPLICIT: RegExp
  ELDRITCH_MOD_R1: string
  ELDRITCH_MOD_R2: string
  ELDRITCH_MOD_R3: string
  ELDRITCH_MOD_R4: string
  ELDRITCH_MOD_R5: string
  ELDRITCH_MOD_R6: string
  SENTINEL_CHARGE: string
  SHAPER_MODS: string[]
  ELDER_MODS: string[]
  CRUSADER_MODS: string[]
  HUNTER_MODS: string[]
  REDEEMER_MODS: string[]
  WARLORD_MODS: string[]
  DELVE_MODS: string[]
  VEILED_MODS: string[]
  INCURSION_MODS: string[]
  FOIL_UNIQUE: string
  UNMODIFIABLE: string
  FOULBORN_NAME: RegExp
  FOULBORN_MODIFIER: string
  ITEM_FLAGS: string[]
  // ---
  CHAT_SYSTEM: RegExp
  CHAT_TRADE: RegExp
  CHAT_GLOBAL: RegExp
  CHAT_PARTY: RegExp
  CHAT_GUILD: RegExp
  CHAT_WHISPER_TO: RegExp
  CHAT_WHISPER_FROM: RegExp
  CHAT_WEBTRADE_GEM: RegExp

  SETTINGS_STASH_CHECK: string
  SETTINGS_STASH_CHECK_POE_LOGIN: string
  SETTINGS_STASH_CHECK_LOGIN: string
  SETTINGS_STASH_CHECK_LOGGED_IN: string
  SETTINGS_STASH_CHECK_NOT_LOGGED_IN: string
  SETTINGS_STASH_CHECK_ITEM_SAVE: string
  SETTINGS_STASH_CHECK_POE_NINJA_PRICE: string
  SETTINGS_STASH_CHECK_POE_NINJA_PRICE_NOTICE: string
  SETTINGS_STASH_CHECK_POE_NINJA_REFRESH: string
  SETTINGS_STASH_CHECK_POE_NINJA_REFRESHING: string
  SETTINGS_STASH_CHECK_POE_NINJA_LAST_UPDATED: string
  SETTINGS_STASH_CHECK_POE_NINJA_NEVER_UPDATED: string
  SETTINGS_STASH_CHECK_POE_NINJA_REFRESH_SUCCESS: string
  SETTINGS_STASH_CHECK_POE_NINJA_REFRESH_FAILED: string
  SETTINGS_STASH_CHECK_POE_NINJA_COOLDOWN: string
  SETTINGS_STASH_CHECK_POE_NINJA_COOLDOWN_MESSAGE: string
  SETTINGS_STASH_CHECK_POE_NINJA_ALREADY_RUNNING: string
  SETTINGS_STASH_CHECK_AUTO_MAP_TIMER: string
  SETTINGS_STASH_CHECK_AUTO_SNAPSHOT: string
  SETTINGS_STASH_CHECK_REFRESH_CHARACTERS: string
  SETTINGS_STASH_CHECK_CONFIRM: string
  SETTINGS_STASH_CHECK_CURRENT_TARGET: string
  SETTINGS_STASH_CHECK_TARGET_CHARACTER: string
  SETTINGS_STASH_CHECK_SELECTED_STASH_TAB_COUNT: string
  SETTINGS_STASH_CHECK_REFRESH_STASH_TABS: string
  SETTINGS_STASH_CHECK_STASH_TABS: string
  SETTINGS_STASH_CHECK_SELECT_ALL_STASH_TABS: string
  SETTINGS_STASH_CHECK_CLEAR_ALL_STASH_TABS: string
  SETTINGS_STASH_CHECK_SELECT_BASIC_STASH_TABS: string
  SETTINGS_STASH_CHECK_CLEAR_BASIC_STASH_TABS: string
  SETTINGS_STASH_CHECK_SELECT_SPECIAL_STASH_TABS: string
  SETTINGS_STASH_CHECK_CLEAR_SPECIAL_STASH_TABS: string
  SETTINGS_STASH_CHECK_TOGGLE_ALL_STASH_TABS: string
  SETTINGS_STASH_CHECK_TOGGLE_BASIC_STASH_TABS: string
  SETTINGS_STASH_CHECK_TOGGLE_SPECIAL_STASH_TABS: string
  SETTINGS_STASH_CHECK_NO_STASH_TABS: string
  SETTINGS_STASH_CHECK_SELECT_STASH_TAB_FIRST: string
  SETTINGS_STASH_CHECK_FETCHING_STASH_TABS: string
  SETTINGS_STASH_CHECK_STASH_TABS_REFRESHED: string
  SETTINGS_STASH_CHECK_STASH_TABS_FAILED: string
  SETTINGS_STASH_CHECK_UNSELECTED: string
  SETTINGS_STASH_CHECK_TAKE_INVENTORY_SNAPSHOT: string
  SETTINGS_STASH_CHECK_TAKE_OWNED_ITEMS_SNAPSHOT: string
  SETTINGS_STASH_CHECK_TAKING_SNAPSHOT: string
  SETTINGS_STASH_CHECK_SELECT_CHARACTER_FIRST: string
  SETTINGS_STASH_CHECK_SELECT_LEAGUE_FIRST: string
  SETTINGS_STASH_CHECK_FETCHING_INVENTORY: string
  SETTINGS_STASH_CHECK_FETCHING_OWNED_ITEMS: string
  SETTINGS_STASH_CHECK_SNAPSHOT_SUCCESS: string
  SETTINGS_STASH_CHECK_OWNED_SNAPSHOT_SUCCESS: string
  SETTINGS_STASH_CHECK_SNAPSHOT_FAILED: string
  SETTINGS_STASH_CHECK_SNAPSHOT_TEMPORARILY_UNAVAILABLE: string
  SETTINGS_STASH_CHECK_SAVE_PATH: string
  SETTINGS_STASH_CHECK_SNAPSHOT_NOTICE_SHORT: string
  SETTINGS_STASH_CHECK_SNAPSHOT_NOTICE_TITLE: string
  SETTINGS_STASH_CHECK_SNAPSHOT_NOTICE_BODY: string
  SETTINGS_STASH_CHECK_SNAPSHOT_NOTICE_ACCEPT: string
  SETTINGS_STASH_CHECK_SNAPSHOT_NOTICE_CANCEL: string
}
